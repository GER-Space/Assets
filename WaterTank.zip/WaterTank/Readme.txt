The actual Water Body/Bodies is just a trigger collider which is referenced by its names by the WaterSurface Nodule

The Water Surfaces is the just a quad at the top of the trigger collider, for computing the water level and later with the adanvedTexture module to be targeted for the pool material.  